<?php
// Get Database connection object
require "db_connect.php";

/* Read csv file and insert into table */
function insertDataFromCsv($csvFile)
{
	global $dbObj;

	$data = array_map('str_getcsv', file($csvFile));

	$rows = count($data);
	$tabCols = "";
	$tabRows = array();

	for ($i=0; $i < $rows && $rows > 1; $i++)
	{

		if ($i == 0 ) 
			$tabCols = "`".implode("`,`",$data[$i]) ."`";
		else 
		{
			foreach ($data[$i] as $key => $val) 
				$data[$i][$key] = $dbObj->escape_string($val);

			$tabRows[] = "('". implode("','",$data[$i]) . "')";
		}
	}	

	if ($rows > 1 )
	{
		$sql = "INSERT INTO original_data ({$tabCols}) VALUES ".implode(",",$tabRows );
		$result = $dbObj->execute_query($sql);	

		return $dbObj->affected_rows();
	}	
	return 0;
}

$csv_file = 'sample-data.csv';

$result = insertDataFromCsv($csv_file);
echo "<br>Record Inserted in original_data Table : ".$result;
?>