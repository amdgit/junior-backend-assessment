<?php
class DbConnect
{
	private $db_host;
	private $db_user;
	private $db_password;
	private $db_name;
	private $db_link;
	protected $result;
	protected $affected_rows;

	public function __construct($db_host, $db_user, $db_password, $db_name ) {

		$this->db_host = $db_host;
		$this->db_user = $db_user;
		$this->db_password = $db_password;
		$this->db_name = $db_name;
		$this->connectDb();
	}

	/* Make database connection */
	public function connectDb()	{

		$this->db_link = new mysqli($this->db_host, $this->db_user, $this->db_password, $this->db_name);

		if ($this->db_link->connect_errno)
		{
			printf("Connect failed %s\n",$this->db_link->connect_error );
			exit();
		}
	}

	/* Runs Select query to get rows from table */
	public function getData($sql) {

		$this->result = $this->db_link->query($sql);

		if ($this->db_link->error)
		{
			printf("Query failed %s\n",$this->db_link->error );
			exit();
		}

		$rows = array();

		if ($this->result->num_rows > 0)
		{
			while($rsObj = $this->result->fetch_assoc())
				$rows[]= $rsObj;

		}	

		$this->result->free();

		return $rows;
	}

	/* Execute insert/update/delete . */
	public function execute_query($sql) {

		$this->result = $this->db_link->query($sql);

		if ($this->db_link->error)
		{
			printf("Query failed %s\n",$this->db_link->error );
			return false;
		}
		else
			return true;

	} 

    public function affected_rows() {

        return $this->db_link->affected_rows;
    }
 
    public function escape_string($value) {
    	
        return $this->db_link->real_escape_string($value);
    }
}
// Get Database connection object
$dbObj = new DbConnect("localhost","root","2010","mindarc_assessment");
?>