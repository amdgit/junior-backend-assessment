<?php
// Get Database connection object
require "db_connect.php";

/* Insert data into migration table from original table */
function migrateData() {
	global $dbObj;
	$sql = "INSERT INTO migrated_data (sku, name)
			SELECT  CONCAT(product_code, if(strcmp(gender,'m'),'_women','_male')) as sku, product_label FROM original_data ORDER BY product_id ASC";
	
	$dbObj->execute_query($sql);		
	return $dbObj->affected_rows();
}

$result = migrateData();
echo "<br>Record Inserted in migrated_data Table : ".$result;
?>