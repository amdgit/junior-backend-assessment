-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 28, 2019 at 07:27 PM
-- Server version: 5.7.25-0ubuntu0.16.04.2
-- PHP Version: 7.1.27-1+ubuntu16.04.1+deb.sury.org+1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mindarc_assessment`
--

-- --------------------------------------------------------

--
-- Table structure for table `migrated_data`
--

CREATE TABLE `migrated_data` (
  `product_id` int(11) NOT NULL,
  `sku` varchar(50) COLLATE utf8mb4_bin NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `image_url` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- Dumping data for table `migrated_data`
--

INSERT INTO `migrated_data` (`product_id`, `sku`, `name`, `image_url`) VALUES
(1, 'red_shirt_male', 'Mens Red Shirt', 'media/img_1.jpeg'),
(2, 'red_blouse_women', 'Womens Red Blouse', 'media/img_2.jpeg'),
(3, 'blue_shorts_male', 'Mens Blue Shorts', 'media/img_3.jpeg'),
(4, 'blue_skirt_women', 'Womens Blue Skirt', 'media/img_4.jpeg'),
(5, 'rainbow_singlet_women', 'Singlet in Rainbow Colours', 'media/img_5.jpeg'),
(6, 'sun_one_women', 'Aviator Sunglasses', 'media/img_6.jpeg'),
(7, 'gold_neck_women', 'Gold Necklace Chain', 'media/img_7.jpeg'),
(8, 'iph_case_women', 'Iphone Case pink', 'media/img_8.jpeg'),
(9, 'sam_case_women', 'Samsung Case Skulls', 'media/img_9.jpeg'),
(10, 'black_shirt_male', 'AC/DC Shirt', 'media/img_10.jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `original_data`
--

CREATE TABLE `original_data` (
  `product_id` int(11) NOT NULL,
  `product_code` varchar(50) COLLATE utf8mb4_bin NOT NULL,
  `product_label` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `gender` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- Dumping data for table `original_data`
--

INSERT INTO `original_data` (`product_id`, `product_code`, `product_label`, `gender`) VALUES
(1, 'red_shirt', 'Mens Red Shirt', 'm'),
(2, 'red_blouse', 'Womens Red Blouse', 'f'),
(3, 'blue_shorts', 'Mens Blue Shorts', 'm'),
(4, 'blue_skirt', 'Womens Blue Skirt', 'f'),
(5, 'rainbow_singlet', 'Singlet in Rainbow Colours', 'v'),
(6, 'sun_one', 'Aviator Sunglasses', 'f'),
(7, 'gold_neck', 'Gold Necklace Chain', ''),
(8, 'iph_case', 'Iphone Case pink', ' F'),
(9, 'sam_case', 'Samsung Case Skulls', 'M'),
(10, 'black_shirt', 'AC/DC Shirt', 'm');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `migrated_data`
--
ALTER TABLE `migrated_data`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `original_data`
--
ALTER TABLE `original_data`
  ADD PRIMARY KEY (`product_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `migrated_data`
--
ALTER TABLE `migrated_data`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `original_data`
--
ALTER TABLE `original_data`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
