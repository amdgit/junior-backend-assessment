<?php
// Get Database connection object
require "db_connect.php";

// Upload file
function imageUpload($source, $destination) {
	if (is_uploaded_file($source['tmp_name']) && $source['error'] == 0)
	{
		$suffix = isset($_POST['prd_id'])?$_POST['prd_id']:uniqid();
		$path = pathinfo($source['name']);
		$ext = $path['extension'];

		// Set upload path, and unique file name with suffix
		$destination .= "img_".$suffix.".".$ext;

		if (is_file($destination)) unlink($destination);

		if ( move_uploaded_file($source['tmp_name'], $destination))
			return $destination;
	}	
	return false;
}

if ( isset($_POST) && count($_POST) > 0 )
{
	$err_msg="Image upload failed";

	$file_path = imageUpload($_FILES['procuct_img'], "media/");

	if ($file_path !== false )
	{
		$sql = "UPDATE migrated_data SET image_url ='".$file_path."' WHERE product_id='".$_POST['prd_id']."'";
		$result = $dbObj->execute_query($sql);
		$err_msg="Image uploaded successfully";
	}	
	header("Location: image-uploader.php?err_msg={$err_msg}");
	exit();
}

/* Fetch rows from table */
$sql = "SELECT * FROM migrated_data where 1 ORDER BY product_id ASC";
$rsData =$dbObj->getData($sql);		
?>
<!DOCTYPE html>
<html>
<head>
<title>MINDARC Test</title>
<style>
	table { width:100%; border:1px solid #ccc; }
	table, th, td {	
	  border-collapse:collapse;
	  border-bottom:1px solid #ccc;
	}
	th, td { padding: 5px;}
	th { text-align: left;}
	table, tr { height: 50px; } 
	table, tr:nth-child(odd) { background-color:#ffffff; } 	
	table, tr:nth-child(even) { background-color: #e8e8e8; } 	
	table, tr:first-child { background-color:#b8b8b8; } 	
	img { width:100px;}
	p { text-align: center; }
</style>	
<script type="text/javascript">
	function validateForm(frmObj) {
		if (frmObj.procuct_img.value == "")
		{
			alert("Please select file to upload");
			return false;
		}	
		return true;
	}
</script>
</head>
<body>
	<?php if ( isset($_GET['err_msg']) && trim($_GET['err_msg']) != '' ) { ?>
	<p><?=$_GET['err_msg']?></p>
	<?php } ?>
	<table>
		<tr>
			<th>&nbsp;</th>
			<th>Sku</th>
			<th>Name</th>
			<th colspan="2">Image</th>
		</tr>	
		<?php if (count($rsData) == 0 ) { ?>		
		<tr>
			<td style="text-align:center;color:red;" colspan="5">No record found</td>
		</tr>
		<?php } ?>

		<?php foreach ($rsData as $key=>$val ): ?>
		<form method="post" action="image-uploader.php" enctype="multipart/form-data" onsubmit="return validateForm(this)">
			<input type="hidden" name="prd_id" value="<?=$val['product_id']?>">
			<tr>
				<td><?=$val['product_id']?></td>
				<td><?=$val['sku']?></td>
				<td><?=$val['name']?></td>
				<td><img src="<?=$val['image_url']?>" alt="No Image"></td>
				<td><input type="file" name="procuct_img" style="">
				<input type="submit" name="submit" value="Upload" >
				</td>
			</tr>
		</form>
		<?php endforeach; ?>
	</table>
</body>
</html>